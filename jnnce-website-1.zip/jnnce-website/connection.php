                <?php
                  $link=mysqli_connect("localhost","root","mysql");
                  mysqli_select_db($link,"dbms");
                  ?>