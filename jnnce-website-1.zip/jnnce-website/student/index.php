<!DOCTYPE html>
<html lang="en">

  <head>
    <style type="text/css">
      body{
        background-image: url(assets/images/css.jpg); 
        background-repeat: no-repeat;
      }
    </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
   

    <title>JNNCE_CSE</title>
    

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
  
    

  </head>

<body>

   
  <!--header-->
  <header class="main-header clearfix" role="header">
    <div class="logo">
      <a ><em>JNNCE</em> CSE_DEPARTMENT</a>
    </div>
<!--     <a href="#menu" class="menu-link">hellO<i class="fa fa-bars"></i></a>
 -->   
   <ul class="main-menu">
        <li><a href="#section1">Home</a></li>
        <li class="has-submenu"><a href="#section2">About Us</a>
          <ul class="sub-menu">
            <li><a >ROHITH</a></li>
            <li><a >SHARATH</a></li>
            <li><a >SANKALP</a></li>
     
          </ul>
        </li>
<!--         <li><a href="#section4">Courses</a></li>
 -->        <!-- <li><a href="#section5">Video</a></li> -->
       <li class="has-submenu"><a href="#section2">About Us</a>
          <ul class="sub-menu">
            <li><a >ROHITH-9620336988</a></li>
            <li><a >SHARATH-8861885594</a></li>
            <li><a >SANKALP-8951864841</a></li>
     
          </ul>
        <!-- <li><a href="https://templatemo.com" class="external">External</a></li> -->
      </ul>
    </nav>
  </header>

  <!-- ***** Main Banner Area Start ***** -->
   <
        

      <div class="caption">
                <h6>CSE_DATA</h6>
              <h2><em>WELCOME</em> TO CSE</h2>
              </div>
              <div class="main-button">
                  <div>
                   <a href="student_login.php" target="blank">Student Login</a>
                   <br><br><br>
                 </div>
                
                 <div>
                   <a href="faculty_login.php" target="blank">Faculty Login</a>
                 </div>
              </div>
          
      </div>

 </body>
 </html>

