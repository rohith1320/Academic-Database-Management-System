<?php 
session_start();
unset($_SESSION["FACULTY"]);
?>
<script type="text/javascript">
	window.location="index.php"
</script>