
<?php
    session_start(); 
?>
<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">
        table, th, td {
  border: 1px solid black;
}
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>JNNCE CSE </title>

<link rel='icon' href="assets/images/c.ico">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/nprogress.css" rel="stylesheet">
    <link href="css/custom.min.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="#" class="site_title"><i class="fa fa-book"></i> <span>JNNCE</span></a>
                </div>

                <div class="clearfix"></div>

                <!-- menu profile quick info -->
                <div class="profile clearfix">
                    <div class="profile_pic">
                       
                    </div>
                    <div class="profile_info">
                        <span>Welcome,</span>

                        <h2><?php echo $_SESSION['User_Name'];?></h2>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <!-- /menu profile quick info -->

                <br/>

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">
                        <h3>General</h3>
                        <ul class="nav side-menu">
                            <li><a href="faculty_interface.php"><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>

                            </li>
                           <!--  <li><a><i class="fa fa-edit"></i> Forms <span class="fa fa-chevron-down"></span></a>

                            </li> -->
                            <li><a href="update_student_ia.php"><i class="fa fa-desktop"></i> UPDATE IA MARKS <span
                                    class="fa fa-chevron-down"></span></a>

                            </li>
                            <!-- <li><a href=time_table1.php><i class="fa fa-table"></i> Tables <span class="fa fa-chevron-down"></span></a>

                            </li> -->
                          <!--   <li><a><i class="fa fa-bar-chart-o"></i> Data Presentation <span
                                    class="fa fa-chevron-down"></span></a>
 -->
                            </li>

                        </ul>
                    </div>


                </div>

            </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <nav>
                    <div class="nav toggle">
                        <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                    </div>

                    <ul class="nav navbar-nav navbar-right">
                        <li class="">
                            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown"
                               aria-expanded="false">
                               <?php echo $_SESSION['User_Name'];?>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu pull-right">
                                <li><a href="logout.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                            </ul>
                        </li>

                        <li role="presentation" class="dropdown">
                            <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown"
                               aria-expanded="false">
                                <i class="fa fa-envelope-o"></i>
                                <span class="badge bg-green">6</span>
                            </a>

                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- /top navigation -->

        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>JNNCE CSE</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>STUDENT DATA</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                 <div class="login_wrapper">

            <section class="login_content" style="margin-top: -40px;">
                <form name="form1" action="" method="post">
                    <h2>STUDENT IA UPDATE</h2><br>
                       <div>
                        <input type="text" class="form-control" placeholder="SUBJECT" name="subject" required=""/>
                    </div>
                       <div>
                        <input type="text" class="form-control" placeholder="STUDENT_NAME" name="username" required=""/>
                    </div>

                    <div>
                        <input type="text" class="form-control" placeholder="IA1" name="ia1" required=""/>
                    </div>
                    <div class="col-lg-12  col-lg-push-3">
                        <input class="btn btn-default submit " type="submit" name="submit2" value="UPLOAD">
                    </div>

              </form>
            </section>

                             <?php
                              if(isset($_POST["submit2"]))
                            {
                                 $link=mysqli_connect("localhost","root","mysql");
                                    mysqli_select_db($link,"dbms");
                                    
                                     $count=0;
                                 $res=mysqli_query($link,"SELECT * FROM student_registration_details WHERE username='$_POST[username]'");
                                $count=mysqli_num_rows($res);
                                 if($count==0)
                                     {
                                        ?>

                                            <div class="alert alert-danger col-lg-6 col-lg-push-3">
                                            <strong style="color:white">Invalid</strong> Student Name
                                            </div>
                                        <?php
                                     }
                                     else
                                     {
                                         mysqli_query($link,"INSERT INTO  student_marks VALUES('$_POST[subject]','$_POST[username]','$_POST[ia1]')");
                                     }
                            }
                                  // $res=mysqli_query($link,"SELECT * FROM time_table_cse");
                                  // echo "<table class='table-bordered' width=90% border=solid black>";
                              
                            //   echo "<tr>";
                            //    echo "<th>";echo "day"; echo "</th>"; echo"<br>";
                            //      echo "<th>";echo "9.30-10.15"; echo "</th>"; 
                            //      echo "<th>";echo "10.15-11.00"; echo "</th>";
                            //      echo "<th>";echo "11.15-12.00"; echo "</th>";
                            //      echo "<th>";echo "12.00-12.45"; echo "</th>";
                            //      echo "<th>";echo "12.45-1.30"; echo "</th>";
                            //      echo "<th>";echo "2.30-3.15"; echo "</th>";
                            //      echo "<th>";echo "3.15-4.00"; echo "</th>";
                            //      echo "<th>";echo "4.00-4.45"; echo "</th>";
                            //      echo "</tr>";
                            // while ($row=mysqli_fetch_array($res))
                            //      {
                            //         echo "<tr>";
                            //         echo "<td>";echo $row["day"]; echo "</td>";
                            //     ; echo "<td>";echo $row["1"]; echo "</td>";
                            //           echo "<td>";echo $row["2"]; echo "</td>";
                            //            echo "<td>";echo $row["3"]; echo "</td>";
                            //             echo "<td>"; echo $row["4"]; echo "</td>";
                            //              echo "<td>"; echo $row["5"]; echo "</td>";
                            //               echo "<td>" ; echo $row["6"]; echo "</td>";
                            //                echo "<td>" ; echo $row["7"]; echo "</td>";
                            //                 echo "<td>"; echo $row["8"]; echo "</td>";
                            //         echo "</tr>";
                            //     }
                                
                            //     echo "</table>";
                                ?> 
                                      
                               

                            </div>


                                
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- /page content -->


        <!-- footer content -->
        <footer>
            <div class="pull-right">
                <!-- Library Management System -->
            </div>
            <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
    </div>
</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- NProgress -->
<script src="js/nprogress.js"></script>

<!-- Custom Theme Scripts -->
<script src="js/custom.min.js"></script>
</body>
</html>
